const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());

class Card {
  constructor(suit, rank) {
    this.suit = suit;
    this.rank = rank;
  }

  getValue() {
    if (this.rank === 'A') return 1;
    if (['J', 'Q', 'K'].includes(this.rank)) return 10;
    return parseInt(this.rank);
  }
}

function createDeck() {
  const suits = ['Spades', 'Hearts', 'Diamonds', 'Clubs'];
  const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck = suits.flatMap(suit => ranks.map(rank => new Card(suit, rank)));
  return deck.sort(() => Math.random() - 0.5);
}

function calculateNiu(cards) {
  for (let i = 0; i < cards.length; i++) {
    for (let j = i + 1; j < cards.length; j++) {
      for (let k = j + 1; k < cards.length; k++) {
        if ((cards[i].getValue() + cards[j].getValue() + cards[k].getValue()) % 10 === 0) {
          const remaining = cards.filter((_, idx) => ![i, j, k].includes(idx));
          const niu = (remaining[0].getValue() + remaining[1].getValue()) % 10;
          return niu;
        }
      }
    }
  }
  return -1; // 无牛
}

app.get('/deal', (req, res) => {
  const deck = createDeck();
  const hand = deck.slice(0, 5);
  const niu = calculateNiu(hand);
  res.json({ hand, niu });
});

app.listen(5000, () => console.log('Server running on port 5000'));