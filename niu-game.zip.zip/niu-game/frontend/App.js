import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [hand, setHand] = useState([]);
  const [niu, setNiu] = useState(null);
  const [autoPlay, setAutoPlay] = useState(false);

  const dealCards = async () => {
    const response = await fetch('https://your-backend-url/deal');
    const data = await response.json();
    setHand(data.hand);
    setNiu(data.niu);
  };

  useEffect(() => {
    if (autoPlay) {
      const interval = setInterval(dealCards, 3000); // 每3秒自动发牌
      return () => clearInterval(interval);
    }
  }, [autoPlay]);

  return (
    <div className="App">
      <h1>马来西亚斗牛扑克牌</h1>
      <button onClick={dealCards}>发牌</button>
      <button onClick={() => setAutoPlay(!autoPlay)}>
        {autoPlay ? '停止自动继续' : '自动继续'}
      </button>
      <div>
        <h2>手牌</h2>
        <ul>
          {hand.map((card, index) => (
            <li key={index}>{card.rank} of {card.suit}</li>
          ))}
        </ul>
      </div>
      <div>
        <h2>牛数</h2>
        <p>{niu !== null ? (niu === -1 ? '无牛' : 牛${niu}) : '未计算'}</p>
      </div>
    </div>
  );
}

export default App;